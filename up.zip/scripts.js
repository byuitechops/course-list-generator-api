function getSemesters(callback){
var domXhr = new XMLHttpRequest
    domXhr.open("GET", "https://pathway.brightspace.com/d2l/api/lp/1.15/enrollments/myenrollments/?orgUnitTypeId=5")
    domXhr.onload = function(e) {
        if(domXhr.status == 200){
            callback(null, domXhr.response)
        } else {
            callback(e, null)
        }
    }
    domXhr.send()
}

function filterSemesters(err, semesters){
    console.log(err, semesters)
}

function updateSemesters(){
    getSemesters(filterSemesters)
}